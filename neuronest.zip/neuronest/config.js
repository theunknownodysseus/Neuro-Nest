// OpenRouter API Configuration
// This file is auto-generated from .env - DO NOT EDIT DIRECTLY
// To change values, edit the .env file and run: node load-env.js

window.NEURONEST_CONFIG = {
  OPENROUTER_API_KEY: "your-openrouter-api-key-here",
  MODEL: "tngtech/tng-r1t-chimera:free"
};
