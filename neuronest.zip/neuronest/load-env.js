const fs = require('fs');
const path = require('path');

// Read .env file
const envPath = path.join(__dirname, '.env');
const configPath = path.join(__dirname, 'config.js');

if (!fs.existsSync(envPath)) {
  console.error('Error: .env file not found!');
  console.log('Please create a .env file with:');
  console.log('  OPENROUTER_API_KEY=your-api-key-here');
  console.log('  MODEL=tngtech/tng-r1t-chimera:free');
  process.exit(1);
}

// Parse .env file
const envContent = fs.readFileSync(envPath, 'utf8');
const envVars = {};

envContent.split('\n').forEach(line => {
  const trimmed = line.trim();
  if (trimmed && !trimmed.startsWith('#')) {
    const [key, ...valueParts] = trimmed.split('=');
    if (key && valueParts.length > 0) {
      envVars[key.trim()] = valueParts.join('=').trim();
    }
  }
});

// Generate config.js
const configContent = `// OpenRouter API Configuration
// Auto-generated from .env - DO NOT EDIT DIRECTLY
// To change values, edit the .env file and run: node load-env.js

window.NEURONEST_CONFIG = {
  OPENROUTER_API_KEY: "${envVars.OPENROUTER_API_KEY || ''}",
  MODEL: "${envVars.MODEL || 'tngtech/tng-r1t-chimera:free'}"
};
`;

fs.writeFileSync(configPath, configContent);
console.log('config.js has been updated from .env');
console.log('API Key:', envVars.OPENROUTER_API_KEY ? '***' + envVars.OPENROUTER_API_KEY.slice(-4) : 'NOT SET');
console.log('Model:', envVars.MODEL || 'tngtech/tng-r1t-chimera:free');
